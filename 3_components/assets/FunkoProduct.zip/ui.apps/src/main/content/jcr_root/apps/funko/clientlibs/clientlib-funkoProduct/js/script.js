function onItemGalleryClicked(elem) {
    Array.from(elem.parentNode.children).forEach(function(item) {
        item.classList.remove("current");
     });
    elem.classList.add("current");
    elem.parentNode.nextElementSibling.children[0].src = elem.children[0].src;
}