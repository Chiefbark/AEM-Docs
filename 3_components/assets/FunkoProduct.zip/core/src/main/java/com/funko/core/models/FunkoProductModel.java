package com.funko.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import static org.apache.sling.api.resource.ResourceResolver.PROPERTY_RESOURCE_TYPE;

@Model(adaptables = Resource.class)
public class FunkoProductModel {

    @ValueMapValue(name = PROPERTY_RESOURCE_TYPE, injectionStrategy = InjectionStrategy.OPTIONAL)
    @Default(values = "No resourceType")
    protected String resourceType;

    @SlingObject
    private Resource currentResource;

    private String item_no;
    private String name;
    private String release;
    private String status;
    private ArrayList<String> gallery;

    @PostConstruct
    protected void init() {
        // Instantiate the arraylist
        this.gallery = new ArrayList<>();
        // Store the fields into our variables
        this.item_no = currentResource.getValueMap().get("item-no", String.class);
        this.name = currentResource.getValueMap().get("name", String.class);
        this.release = currentResource.getValueMap().get("release", String.class);

        // If the release date is not null
        if (this.release != null)
            try {
                // Compares the release date and the current date
                SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
                Date d1 = sdformat.parse(this.release);
                Date d2 = new Date();
                if (d1.compareTo(d2) > 0)
                    this.status = "Coming soon";
                else
                    this.status = "Available";
            } catch (Exception e) {
                this.status = "Unavailable";
                e.printStackTrace();
            }
        // Get the multiple field
        Resource multi = currentResource.getChild("gallery");
        if (multi != null) {
            Iterator<Resource> children = multi.listChildren();
            // Iterate for each item
            while (children.hasNext()) {
                // Get the image and save it into the arraylist
                String image = children.next().getValueMap().get("image", String.class);
                this.gallery.add(image);
            }
        }
    }

    public String getItem_no() {
        return item_no;
    }

    public String getName() {
        return name;
    }

    public String getRelease() {
        return release;
    }

    public String getReleaseYear() {
        return release.split("-")[0];
    }

    public String getStatus() {
        return status;
    }

    public ArrayList<String> getGallery() {
        return gallery;
    }
}
