package com.funko.core.models;

import com.adobe.cq.dam.cfm.ContentFragment;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;

import static org.apache.sling.api.resource.ResourceResolver.PROPERTY_RESOURCE_TYPE;

@Model(adaptables = Resource.class)
public class FunkoProductModel {

    @ValueMapValue(name = PROPERTY_RESOURCE_TYPE, injectionStrategy = InjectionStrategy.OPTIONAL)
    @Default(values = "No resourceType")
    protected String resourceType;

    @SlingObject
    private Resource currentResource;
    @SlingObject
    private ResourceResolver resourceResolver;

    private String cf;
    private String item_no;
    private String name;
    private String release;
    private String status;
    private ArrayList<String> gallery;
    private String[] tags;

    @PostConstruct
    protected void init() {
        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

        Page currentPage = pageManager.getContainingPage(currentResource);
        // Get the tags from the page properties
        this.tags = currentPage.getProperties().get("cq:tags", String[].class);
        // Since the value is similar to 'funko:category/pop!', we just want the last tag name
        for (int ii = 0; ii < this.tags.length; ii++)
            this.tags[ii] = this.tags[ii] = this.tags[0].substring(this.tags[ii].lastIndexOf("/") + 1);

        // Store the fields into our variables
        this.item_no = currentResource.getValueMap().get("item-no", String.class);
        this.name = currentResource.getValueMap().get("name", String.class);
        // If no name provided, select the name from the page properties
        if (this.name == null)
            this.name = currentPage.getProperties().get("default-name", String.class);
        this.release = currentResource.getValueMap().get("release", String.class);

        this.gallery = new ArrayList<>();
        // Get the multiple field
        Resource multi = currentResource.getChild("gallery");
        if (multi != null) {
            Iterator<Resource> children = multi.listChildren();
            // Iterate for each item
            while (children.hasNext()) {
                // Get the image and save it into the arraylist
                String image = children.next().getValueMap().get("image", String.class);
                this.gallery.add(image);
            }
        }

        // Get the content fragment path
        this.cf = currentResource.getValueMap().get("cf", String.class);
        if (this.cf != null) {
            // Covert it to a ContentFragment object
            Resource resourceChild = resourceResolver.getResource(this.cf);
            ContentFragment contentFragment = resourceChild.adaptTo(ContentFragment.class);

            // If any of the values are null, set the content fragment values
            if (this.item_no == null)
                this.item_no = contentFragment.getElement("item-no").getValue().getValue(String.class);
            if (this.name == null)
                this.name = contentFragment.getElement("name").getValue().getValue(String.class);
            if (this.release == null)
                this.release = contentFragment.getElement("release").getValue().getValue(String.class);
            if (this.gallery == null || this.gallery.size() == 0)
                this.gallery.addAll(Arrays.asList(contentFragment.getElement("gallery").getValue().getValue(String[].class)));
        }

        // If no gallery provided, select the default image from page properties
        if (this.gallery.size() == 0)
            this.gallery.add(currentPage.getProperties().get("default-image", String.class));

        // If the release date is not null
        if (this.release != null)
            try {
                // Compares the release date and the current date
                SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
                Date d1 = sdformat.parse(this.release);
                Date d2 = new Date();
                if (d1.compareTo(d2) > 0)
                    this.status = "Coming soon";
                else
                    this.status = "Available";
            } catch (Exception e) {
                this.status = "Unavailable";
                e.printStackTrace();
            }
    }

    public String getCf() {
        return this.cf;
    }

    public String getItem_no() {
        return item_no;
    }

    public String getName() {
        return name;
    }

    public String getRelease() {
        return release;
    }

    public String getReleaseYear() {
        return release.split("-")[0];
    }

    public String getStatus() {
        return status;
    }

    public ArrayList<String> getGallery() {
        return gallery;
    }

    public String[] getTags() {
        return tags;
    }
}
